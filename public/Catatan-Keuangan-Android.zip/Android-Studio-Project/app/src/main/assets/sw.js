/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "448d4b4800db3a5c5e34a93918133831"
  }, {
    "url": "pwa-512x512.png",
    "revision": "374e67be7d493aa6f2fc09b0c95b0ff5"
  }, {
    "url": "pwa-192x192.png",
    "revision": "2a26584d1c527b3ea8d3bcf24289cc79"
  }, {
    "url": "index.html",
    "revision": "f60e6a83cfcb7c2300b5947ea3629617"
  }, {
    "url": "icon.svg",
    "revision": "9454808302b87df0b72b726d89425081"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "760a5213f70c01d18340374628f0dac5"
  }, {
    "url": "assets/index-Dd97ePY8.js",
    "revision": null
  }, {
    "url": "assets/index-BypAl39m.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "760a5213f70c01d18340374628f0dac5"
  }, {
    "url": "icon.svg",
    "revision": "9454808302b87df0b72b726d89425081"
  }, {
    "url": "pwa-192x192.png",
    "revision": "2a26584d1c527b3ea8d3bcf24289cc79"
  }, {
    "url": "pwa-512x512.png",
    "revision": "374e67be7d493aa6f2fc09b0c95b0ff5"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "448d4b4800db3a5c5e34a93918133831"
  }, {
    "url": "manifest.webmanifest",
    "revision": "19e1fb60d30a97d611509e3bb9dc85ea"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
